package model;

import model.exceptions.EmptyStringException;
import model.exceptions.InvalidProgressException;
import model.exceptions.NegativeInputException;
import model.exceptions.NullArgumentException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Calendar;
import java.util.Date;
import java.util.InvalidPropertiesFormatException;

import static org.junit.jupiter.api.Assertions.*;

class TestTask {
    // TODO: design tests for new behaviour added to Task class
    private Task testTask1;
    private Task testTask2;
    private Tag testTag1;
    private Tag testTag2;
    private Tag testTag3;
    private Calendar c;
    //    private Task testTask3;
//    private Task testTask4;
//    private Task testTask5;
    @BeforeEach
    public void runBefore() {
        c = Calendar.getInstance();
        testTask1 = new Task("testTask1");
        testTask1.setStatus(Status.DONE);
        testTask1.setPriority(new Priority(3));
        testTask1.setDueDate(new DueDate(c.getTime()));
        testTag1 = new Tag("testTag1");
        testTag2 = new Tag("testTag2");
        testTag3 = new Tag("testTag3");
    }
    @Test
    public void testConstructor() {
        Task testTask = new Task("testTask");
        assertEquals(0,testTask.getProgress());
        assertEquals(0,testTask.getEstimatedTimeToComplete());
        assertEquals("testTask", testTask.getDescription());
        assertEquals(null,testTask.getDueDate());
        assertFalse(testTask.getPriority().isImportant());
        assertFalse(testTask.getPriority().isUrgent());
        assertEquals(Status.TODO,testTask.getStatus());
    }
    @Test
    public void testConstructorWithEmptyStringException() {
        try {
            Task testTask = new Task("");
            fail("An EmptyStringException should have been thrown");
        } catch (EmptyStringException e) {
            // expected
        }
    }
    @Test
    public void testTaskEqualsTrue() {
        testTask2 = new Task("testTask1");
        testTask2.setStatus(Status.DONE);
        testTask2.setPriority(new Priority(3));
        testTask2.setDueDate(new DueDate(c.getTime()));
        assertTrue(testTask1.equals(testTask2));
    }
    @Test
    public void testEqualsFalseWithNullParameter() {
        assertFalse(testTask1.equals(null));
    }
    @Test
    public void testTaskEqualsFalseByDescription() {
        testTask2 = new Task("testTask2");
        testTask2.setStatus(Status.DONE);
        testTask2.setPriority(new Priority(3));
        testTask2.setDueDate(new DueDate(c.getTime()));
        assertFalse(testTask1.equals(testTask2));
    }
    @Test
    public void testTaskEqualsFalseByStatus() {
        testTask2 = new Task("testTask1");
        testTask2.setStatus(Status.TODO);
        testTask2.setPriority(new Priority(3));
        testTask2.setDueDate(new DueDate(c.getTime()));
        assertFalse(testTask1.equals(testTask2));
    }
    @Test
    public void testTaskEqualsFalseByDueDate() {
        DueDate testDue = new DueDate(c.getTime());
        testDue.postponeOneDay();
        testTask2 = new Task("testTask2");
        testTask2.setStatus(Status.DONE);
        testTask2.setPriority(new Priority(3));
        testTask2.setDueDate(testDue);
        assertFalse(testTask1.equals(testTask2));
    }
    @Test
    public void testTaskEqualsFalseByPriority() {
        testTask2 = new Task("testTask1");
        testTask2.setStatus(Status.TODO);
        testTask2.setPriority(new Priority(4));
        testTask2.setDueDate(new DueDate(c.getTime()));
        assertFalse(testTask1.equals(testTask2));
    }
    @Test
    public void testAddOneTag() {
        testTask1.addTag(testTag1);
        assertTrue(testTask1.containsTag(testTag1));
        assertTrue(testTag1.containsTask(testTask1));
    }
    @Test
    public void testAddMultipleTasks() {
        testTask1.addTag(testTag1);
        assertTrue(testTask1.containsTag(testTag1));
        assertTrue(testTag1.containsTask(testTask1));
        testTask1.addTag(testTag2);
        assertTrue(testTask1.containsTag(testTag2));
        assertTrue(testTag2.containsTask(testTask1));
        testTask1.addTag(testTag3);
        assertTrue(testTask1.containsTag(testTag3));
        assertTrue(testTag3.containsTask(testTask1));
    }
    @Test
    public void testRemoveOneTask() {
        testTask1.addTag(testTag1);
        testTask1.removeTag(testTag1);
        assertFalse(testTask1.containsTag(testTag1));
        assertFalse(testTag1.containsTask(testTask1));
    }
    @Test
    public void testRemoveMultipleTasks() {
        testTask1.addTag(testTag1);
        testTask1.addTag(testTag2);
        testTask1.addTag(testTag3);
        testTask1.removeTag(testTag1);
        assertFalse(testTask1.containsTag(testTag1));
        assertFalse(testTag1.containsTask(testTask1));
        testTask1.removeTag(testTag2);
        assertFalse(testTask1.containsTag(testTag2));
        assertFalse(testTag2.containsTask(testTask1));
        testTask1.removeTag(testTag3);
        assertFalse(testTask1.containsTag(testTag3));
        assertFalse(testTag3.containsTask(testTask1));
    }
    @Test
    public void testAddTaskNullArgumentException() {
        try {
            testTask1.addTag((Tag) null);
            fail("Empty tag should not be added here");
        } catch (Exception e) {
            // expected
        }
    }
    @Test
    public void testSetProgress() {
        assertEquals(0,testTask1.getProgress());
        testTask1.setProgress(50);
        assertEquals(50,testTask1.getProgress());
        testTask1.setProgress(80);
        assertEquals(80,testTask1.getProgress());
        testTask1.setProgress(100);
        assertEquals(100,testTask1.getProgress());
    }
    @Test
    public void testSetProgressWithInvalidProgressExceptionLowerBoundaryCondition() {
        assertEquals(0,testTask1.getProgress());
        try {
            testTask1.setProgress(-1);
            fail ("InvalidProgressException should have been thrown.");
        } catch (InvalidProgressException e) {
             // expected
        }
    }
    @Test
    public void testSetProgressWithInvalidProgressExceptionUpperBoundaryCondition() {
        assertEquals(0,testTask1.getProgress());
        try {
            testTask1.setProgress(101);
            fail ("InvalidProgressException should have been thrown.");
        } catch (InvalidProgressException e) {
            // expected
        }
    }
    @Test
    public void testSetEstimatedTimeToCompleteBoundaryCase() {
        assertEquals(0,testTask1.getEstimatedTimeToComplete());
        testTask1.setEstimatedTimeToComplete(0);
        assertEquals(0,testTask1.getEstimatedTimeToComplete());
    }
    @Test
    public void testSetEstimatedTimeToComplete() {
        assertEquals(0,testTask1.getEstimatedTimeToComplete());
        testTask1.setEstimatedTimeToComplete(100);
        assertEquals(100, testTask1.getEstimatedTimeToComplete());
    }
    @Test
    public void testSetEstimatedTimeToCompleteWithNegativeInputException() {
        assertEquals(0,testTask1.getEstimatedTimeToComplete());
        try {
            testTask1.setEstimatedTimeToComplete(-1);
            fail ("A NegativeInputException should have been thrown");
        } catch (NegativeInputException e) {
            // expected
        }
    }
    @Test
    public void TestAddTag() {
        testTask1.addTag("testTask1");
        assertEquals(1,testTask1.getTags().size());
        assertEquals("[#testTask1]",testTask1.getTags().toString());
    }
    @Test
    public void TestSetStatusNullArgumentException() {
        try {
            testTask1.setStatus(null);
            fail("A NullArgumentException should have thrown");
        } catch (NullArgumentException e) {
            //expected
        }
    }
    @Test
    public void TestSetDescriptionEmptyStringException() {
        try {
            testTask1.setDescription("");
            fail("an EmptyStringException should have been thrown");
        } catch (EmptyStringException e) {
            //expected
        }
    }
    @Test
    public void TestSetDescriptionNulltringException() {
        try {
            testTask1.setDescription(null);
            fail("an EmptyStringException should have been thrown");
        } catch (EmptyStringException e) {
            //expected
        }
    }
    @Test
    public void TestContainsTagFalse() {
        testTask1.addTag(testTag1);
        assertFalse(testTask1.containsTag("testTag"));
    }
    @Test
    public void TestContainsTagTrue() {
        testTask1.addTag(testTag1);
        assertTrue(testTask1.containsTag("testTag1"));
    }
    @Test
    public void TestContainsTagEmptyTagNameException() {
        try {
            testTask1.containsTag("");
            fail("The length of tagName cannot be 0");
        } catch (EmptyStringException e) {
            // expected
        }
    }
    @Test
    public void TestContainsTagNullTagNameException() {
        String nullString = null;
        try {
            testTask1.containsTag(nullString);
            fail("The length of tagName cannot be 0");
        } catch (EmptyStringException e) {
            // expected
        }
    }
    @Test
    public void TestToString() {
        String taskString =
                    "\n{\n"
                     +  "\tDescription: Read collaboration policy of the term project\n"
                     +  "\tDue date: \n"
                     +  "\tStatus: IN PROGRESS\n"
                     +  "\tPriority: IMPORTANT & URGENT\n"
                     +  "\tTags: #cpsc210\n"
                            +"}";
        Tag t = new Tag("cpsc210");
        testTask1.setDescription("Read collaboration policy of the term project");
        testTask1.addTag(t);
        testTask1.setDueDate(null);
        testTask1.setStatus(Status.IN_PROGRESS);
        Priority p = new Priority(1);
        testTask1.setPriority(p);
       assertEquals(taskString,testTask1.toString());
    }
    @Test
    public void TestRemoveTag() {
        testTask1.addTag(testTag1);
        assertTrue(testTask1.containsTag(testTag1));
        testTask1.removeTag("testTag1");
        assertFalse(testTask1.containsTag(testTag1));
    }
    @Test
    public void TestEquals() {
        assertTrue(testTask1.equals(testTask1));
        assertTrue(testTask1.equals(testTask1));
    }
}
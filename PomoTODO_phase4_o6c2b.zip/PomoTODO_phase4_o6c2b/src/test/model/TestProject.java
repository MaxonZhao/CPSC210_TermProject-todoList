package model;

import model.exceptions.EmptyStringException;
import model.exceptions.NullArgumentException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Iterator;
import java.util.NoSuchElementException;

import static org.junit.jupiter.api.Assertions.*;

public class TestProject {
    private Project testProject;
    private String description;
    private Task testTask;
    Task testTask1 = new Task("1");
    Task importantAndUrgentTask;
    Task importantButNotUrgentTask;
    Task urgentButNotImportantTask;
    Task neitherImportantNorUrgentTask;
    Project importantAndUrgentProject;
    Project importantButNotUrgentProject;
    Project urgentButNotImportantProject;
    Project neitherImportantNorUrgentProject;
    Priority importantAndUrgentPriority = new Priority(1);
    Priority importantButNotUrgentPriority = new Priority(2);
    Priority urgentButNotImportantPriority = new Priority(3);
    Priority neitherImportantNorUrgentPriority = new Priority(4);

    @BeforeEach
    public void runBefore() {
        description =  "CPSC 210 TERM PROJECT WINTER 2018/2019";
        testProject = new Project(description);
        testTask = new Task("CPSC 210 Term Project Phase 1");

        //  Instantiate tasks
        importantAndUrgentTask = new Task("important and urgent task");
        importantButNotUrgentTask = new Task("important but not urgent task");
        urgentButNotImportantTask = new Task("urgent but not important task");
        neitherImportantNorUrgentTask = new Task("neither important nor urgent task");

        // Instantiate projects
        importantAndUrgentProject = new Project("important and urgent project");
        importantButNotUrgentProject = new Project("important but not urgent project");
        urgentButNotImportantProject = new Project("urgent but not important project");
        neitherImportantNorUrgentProject = new Project("neither important nor urgent project");

        // set priority for tasks
        importantAndUrgentTask.setPriority(importantAndUrgentPriority);
        importantButNotUrgentTask.setPriority(importantButNotUrgentPriority);
        urgentButNotImportantTask.setPriority(urgentButNotImportantPriority);
        neitherImportantNorUrgentTask.setPriority(neitherImportantNorUrgentPriority);

        // set priority for projects
        importantAndUrgentProject.setPriority(importantAndUrgentPriority);
        importantButNotUrgentProject.setPriority(importantButNotUrgentPriority);
        urgentButNotImportantProject.setPriority(urgentButNotImportantPriority);
        neitherImportantNorUrgentProject.setPriority(neitherImportantNorUrgentPriority);
    }

    @Test
    public void TestConstructor() {
        assertEquals(description,testProject.getDescription());
        assertEquals(0,testProject.getNumberOfTasks());
    }
    @Test
    public void TestConstructorOverLoadException() {
        try {
            testProject = new Project("");
            fail("It should throw an exception");
        } catch (EmptyStringException e) {
            // expected
        }
        try {
            testProject = new Project(null);
            fail("It should throw an exception");
        } catch (EmptyStringException e) {
            // expected
        }
    }
    @Test
    public void TestAddException() {
        try {
            testProject.add(null);
            fail("It should throw an exception");
        } catch (NullArgumentException e) {
            // expected
        }
    }
    @Test
    public void TestRemoveException() {
        try {
            testProject.remove(null);
            fail("It should throw an exception");
        } catch (NullArgumentException e) {
            // expected
        }
    }
    @Test
    public void TestContainsException() {
        try {
            testProject.contains(null);
            fail("It should throw an exception");
        } catch (NullArgumentException e) {
            // expected
        }
    }
    @Test
    public void TestAdd() {
        assertFalse(testProject.contains(testTask));
        assertEquals(0,testProject.getNumberOfTasks());
        testProject.add(testTask);
        assertEquals(1, testProject.getNumberOfTasks());
        assertTrue(testProject.contains(testTask));
        testProject.add(testTask);
    }
    @Test
    public void TestAddProjectToItselfAsSub_Project() {
        assertFalse(testProject.contains(testProject));
        assertEquals(0,testProject.getNumberOfTasks());
        testProject.add(testProject);
        assertFalse(testProject.contains(testProject));
        assertEquals(0,testProject.getNumberOfTasks());
    }
    @Test
    public void TestRemove() {
        assertEquals(0,testProject.getNumberOfTasks());
        assertFalse(testProject.contains(testTask));
        testProject.remove(testTask);
        assertFalse(testProject.contains(testTask));
        testProject.add(testTask);
        assertEquals(1,testProject.getNumberOfTasks());
        assertTrue(testProject.contains(testTask));
        testProject.remove(testTask);
        assertEquals(0,testProject.getNumberOfTasks());
        assertFalse(testProject.contains(testTask));
    }
    @Test
    public void TestGetEstimatedTimeToCompleteWithOneProjectAndNoTask() {
        assertEquals(0,testProject.getEstimatedTimeToComplete());
    }
    @Test
    public void TestGetEstimatedTimeToCompleteWithOneProjectAndOneTask() {
        assertEquals(0,testProject.getEstimatedTimeToComplete());
        testTask.setEstimatedTimeToComplete(100);
        testProject.add(testTask);
        assertEquals(100,testProject.getEstimatedTimeToComplete());
        testTask.setEstimatedTimeToComplete(50);
        assertEquals(50,testProject.getEstimatedTimeToComplete());
    }
    @Test
    public void TestGetEstimatedTimeToCompleteWithOneProjectAndMultipleTasks() {
        assertEquals(0,testProject.getEstimatedTimeToComplete());
        testProject.add(testTask);
        assertEquals(0,testProject.getEstimatedTimeToComplete());
        testTask.setEstimatedTimeToComplete(100);
        assertEquals(100,testProject.getEstimatedTimeToComplete());
        Task testTask2 = new Task("testTask2");
        testProject.add(testTask2);
        testTask2.setEstimatedTimeToComplete(20);
        testTask2.setEstimatedTimeToComplete(40);
        assertEquals(140,testProject.getEstimatedTimeToComplete());
    }
    @Test
    public void TestGetEstimatedTimeToCompleteWithMultipleTasksAndOneSubProjectAndOneTaskInIt() {
        assertEquals(0,testProject.getEstimatedTimeToComplete());
        testProject.add(testTask);
        assertEquals(0,testProject.getEstimatedTimeToComplete());
        testTask.setEstimatedTimeToComplete(100);
        assertEquals(100,testProject.getEstimatedTimeToComplete());
        Task testTask2 = new Task("testTask2");
        testProject.add(testTask2);
        testTask2.setEstimatedTimeToComplete(20);
        assertEquals(120,testProject.getEstimatedTimeToComplete());
        Project testProject1 = new Project("testProject1");
        Task testTask3 = new Task("testTask3");
        testProject1.add(testTask3);
        testTask3.setEstimatedTimeToComplete(300);
        testProject.add(testProject1);
        assertEquals(420,testProject.getEstimatedTimeToComplete());
        testTask3.setEstimatedTimeToComplete(30);
        assertEquals(150,testProject.getEstimatedTimeToComplete());
        testTask2.setEstimatedTimeToComplete(0);
        assertEquals(130,testProject.getEstimatedTimeToComplete());
    }
    @Test
    public void TestGetEstimatedTimeToCompleteWithMultipleSubProjectsAndTasksInThem() {
        Task t = new Task("...");
        assertEquals(0,testProject.getEstimatedTimeToComplete());
        testProject.add(importantAndUrgentProject);
        testProject.add(urgentButNotImportantProject);
        testProject.add(t);
        importantAndUrgentProject.add(importantButNotUrgentTask);
        importantAndUrgentProject.add(neitherImportantNorUrgentTask);
        urgentButNotImportantProject.add(neitherImportantNorUrgentTask);
        assertEquals(0,testProject.getEstimatedTimeToComplete());
        importantButNotUrgentTask.setEstimatedTimeToComplete(100);
        assertEquals(100,importantAndUrgentProject.getEstimatedTimeToComplete());
        assertEquals(0,urgentButNotImportantProject.getEstimatedTimeToComplete());
        assertEquals(100,testProject.getEstimatedTimeToComplete());
        neitherImportantNorUrgentTask.setEstimatedTimeToComplete(20);
        assertEquals(140,testProject.getEstimatedTimeToComplete());
        assertEquals(120,importantAndUrgentProject.getEstimatedTimeToComplete());
        assertEquals(20,urgentButNotImportantProject.getEstimatedTimeToComplete());
        testProject.remove(importantAndUrgentProject);
        assertEquals(20,testProject.getEstimatedTimeToComplete());
        importantButNotUrgentTask.setEstimatedTimeToComplete(0);
        assertEquals(20,testProject.getEstimatedTimeToComplete());
        assertEquals(20,importantAndUrgentProject.getEstimatedTimeToComplete());
        t.setEstimatedTimeToComplete(100);
        assertEquals(120,testProject.getEstimatedTimeToComplete());
        testProject.remove(t);
        assertEquals(20,testProject.getEstimatedTimeToComplete());
        t.setEstimatedTimeToComplete(2000);
        assertEquals(20,testProject.getEstimatedTimeToComplete());
    }
    @Test
    public void TestGetEstimatedRemove() {
        testProject.add(importantAndUrgentProject);
        importantAndUrgentProject.add(testTask);
        testTask.setEstimatedTimeToComplete(100);
        assertEquals(100,testProject.getEstimatedTimeToComplete());
        testProject.remove(importantAndUrgentProject);
        assertEquals(0,testProject.getEstimatedTimeToComplete());
        importantAndUrgentProject.remove(testTask);
        assertEquals(0,testProject.getEstimatedTimeToComplete());
        testTask.setEstimatedTimeToComplete(100);
        assertEquals(0,testProject.getEstimatedTimeToComplete());

    }
    @Test
    public void TestGetProgressWithOneProject() {
        Task testTask2 = new Task("testTask3");
        Task testTask1 = new Task("1");
        assertEquals(0, testProject.getNumberOfTasks());
        assertEquals( 0, testProject.getProgress());
        testProject.add(testTask);
        assertEquals(0, testProject.getProgress());
        testProject.add(testTask1);
        testTask1.setProgress(15);
        assertEquals(7 , testProject.getProgress());
        testTask2.setProgress(45);
        testProject.add(testTask2);
        assertEquals(20,testProject.getProgress());
    }

    @Test
    public void TestGetProgressWithMultipleProjects() {
        Task testTask2 = new Task("testTask3");
        Task testTask1 = new Task("1");
        Project testProject1 = new Project("testProject1");
        Task testTask3 = new Task("testTask3");
        Task testTask4 = new Task("testTask4");
        testProject1.add(testTask3);
        assertEquals(0, testProject.getNumberOfTasks());
        assertEquals( 0, testProject.getProgress());
        testProject.add(testTask);
        assertEquals(0, testProject.getProgress());
        testProject.add(testTask1);
        testTask1.setProgress(15);
        assertEquals(7 , testProject.getProgress());
        testTask2.setProgress(45);
        testProject.add(testTask2);
        assertEquals(20,testProject.getProgress());
        testProject.add(testProject1);
        testTask3.setProgress(20);
        assertEquals(20,testProject.getProgress());
        testTask4.setProgress(50);
        testProject1.add(testTask4);
        assertEquals(27,testProject.getProgress());
        Project testProject2 = new Project("testProject3");
        Task testTask5 = new Task("testTask4");
        testProject2.add(testTask5);
        testTask5.setProgress(35);
        testProject.add(testProject2);
        assertEquals(30, testProject.getProgress());
    }

    // TODO: TestIsCompleted methods

    @Test
    public void TestIsCompletedEmpty() {
        assertFalse(testProject.isCompleted());
    }
    @Test
    public void TestIsCompletedNonEmpty_OneTaskTODO() {
        assertFalse(testProject.isCompleted());
        testProject.add(importantAndUrgentTask);
        importantAndUrgentTask.setProgress(50);
        assertFalse(testProject.isCompleted());
    }
    @Test
    public void TestIsCompletedNonEmpty_OneTaskDONE() {
        assertFalse(testProject.isCompleted());
        testProject.add(importantAndUrgentTask);
        importantAndUrgentTask.setProgress(100);
        assertTrue(testProject.isCompleted());
    }
    @Test
    public void TestIsCompletedNonEmpty_TwoTaskTODO() {
        assertFalse(testProject.isCompleted());
        testProject.add(importantAndUrgentTask);
        importantAndUrgentTask.setProgress(50);
        importantButNotUrgentTask.setProgress(50);
        testProject.add(importantButNotUrgentTask);
        assertFalse(testProject.isCompleted());
    }
    @Test
    public void TestIsCompletedNonEmpty_TwoTaskWithFirstTODO() {
        assertFalse(testProject.isCompleted());
        testProject.add(importantAndUrgentTask);
        importantAndUrgentTask.setProgress(50);
        importantButNotUrgentTask.setProgress(100);
        testProject.add(importantButNotUrgentTask);
        assertFalse(testProject.isCompleted());
    }
    @Test
    public void TestIsCompletedNonEmpty_TwoTaskWithSecondTODO() {
        assertFalse(testProject.isCompleted());
        testProject.add(importantAndUrgentTask);
        importantAndUrgentTask.setProgress(100);
        importantButNotUrgentTask.setProgress(50);
        testProject.add(importantButNotUrgentTask);
        assertFalse(testProject.isCompleted());
    }
    @Test
    public void TestIsCompletedNonEmpty_TwoTaskDONE() {
        assertFalse(testProject.isCompleted());
        testProject.add(importantAndUrgentTask);
        importantAndUrgentTask.setProgress(100);
        importantButNotUrgentTask.setProgress(100);
        testProject.add(importantButNotUrgentTask);
        assertTrue(testProject.isCompleted());
    }
    @Test
    public void TestIsCompletedNonEmpty_TwoEmptyProjects() {
        assertFalse(testProject.isCompleted());
        testProject.add(importantAndUrgentProject);
        testProject.add(importantButNotUrgentProject);
        assertFalse(testProject.isCompleted());
    }
    @Test
    public void TestIsCompletedNonEmpty_TwoTodoWithFinishedTasks() {
        assertFalse(testProject.isCompleted());
        testProject.add(importantAndUrgentProject);
        importantAndUrgentTask.setProgress(100);
        importantAndUrgentProject.add(importantAndUrgentTask);
        importantButNotUrgentTask.setProgress(100);
        importantButNotUrgentProject.add(importantButNotUrgentTask);
        testProject.add(importantButNotUrgentProject);
        assertFalse(testProject.isCompleted());
    }
    @Test
    public void TestIsCompletedNonEmpty_TwoTodoWithUnfinishedTasks() {
        assertFalse(testProject.isCompleted());
        testProject.add(importantAndUrgentProject);
        importantAndUrgentTask.setProgress(50);
        importantAndUrgentProject.add(importantAndUrgentTask);
        importantButNotUrgentTask.setProgress(10);
        importantButNotUrgentProject.add(importantButNotUrgentTask);
        testProject.add(importantButNotUrgentProject);
        assertFalse(testProject.isCompleted());
    }
    @Test
    public void TestContains() {
        assertFalse(testProject.contains(testTask));
        testProject.add(testTask);
        assertTrue(testProject.contains(testTask));
    }
    @Test
    public void TestHashCode() {
        Project testProject2 = new Project("testProject");
        Project testProject3 = new Project("testProject");
        assertTrue(testProject2.hashCode() == testProject3.hashCode());
    }

    @Test
    public void TestIteratorWithOneImportantAndUrgentTodo() {
        testProject.add(importantAndUrgentProject);
        for (Todo t: testProject) {
            assertEquals(importantAndUrgentPriority,t.getPriority());
        }
    }
    @Test
    public void TestIteratorWithMultipleImportantAndUrgentTodo() {
        testProject.add(importantAndUrgentTask);
        testProject.add(importantAndUrgentProject);
        for (Todo t:testProject) {
            assertEquals(importantAndUrgentPriority,t.getPriority());
        }
    }
    @Test
    public void TestIteratorWithOneImportantButNotUrgentTodo() {
        testProject.add(importantButNotUrgentTask);
        for (Todo t: testProject) {
            assertEquals(importantButNotUrgentPriority,t.getPriority());
        }
    }
    @Test
    public void TestIteratorWithMultipleImportantButNotUrgentTodo() {
        testProject.add(importantButNotUrgentTask);
        testProject.add(importantButNotUrgentProject);
        for (Todo t: testProject) {
            assertEquals(importantButNotUrgentPriority,t.getPriority());
        }
    }
    @Test
    public void TestIteratorWithOneUrgentButNotImportantTodo() {
        testProject.add(urgentButNotImportantTask);
        for (Todo t: testProject) {
            assertEquals(urgentButNotImportantPriority,t.getPriority());
        }
    }
    @Test
    public void TestIteratorWithMultipleUrgentButNotImportantTodo() {
        testProject.add(urgentButNotImportantTask);
        testProject.add(urgentButNotImportantProject);
        for (Todo t: testProject) {
            assertEquals(urgentButNotImportantPriority,t.getPriority());
        }
    }
    @Test
    public void TestIteratorWithOneNeitherImportantNorUrgentTodo() {
        testProject.add(neitherImportantNorUrgentTask);
        for (Todo t: testProject) {
            assertEquals(neitherImportantNorUrgentPriority,t.getPriority());
        }
    }
    @Test
    public void TestIteratorWithMultipleNeitherImportantNorUrgentTodo() {
        testProject.add(neitherImportantNorUrgentTask);
        testProject.add(neitherImportantNorUrgentProject);
        for (Todo t: testProject) {
            assertEquals(neitherImportantNorUrgentPriority,t.getPriority());
        }
    }
    @Test
    public void TestIteratorWithMixedOneFirstPriorityAndSecondPriority() {
        testProject.add(importantAndUrgentTask);
        testProject.add(importantButNotUrgentProject);
        int counter = 0;
        for (Todo t: testProject) {
            counter++;
            if (counter == 1) {
                assertEquals(importantAndUrgentPriority, t.getPriority());
            } else {
                assertEquals(importantButNotUrgentPriority, t.getPriority());
            }
        }
    }
    @Test
    public void TestIteratorWithMixedOneSecondPriorityAndFirstPriority() {
        testProject.add(importantButNotUrgentProject);
        testProject.add(importantAndUrgentTask);
        int counter = 0;
        for (Todo t: testProject) {
            counter++;
            if (counter == 1) {
                assertEquals(importantAndUrgentPriority, t.getPriority());
            } else {
                assertEquals(importantButNotUrgentPriority, t.getPriority());
            }
        }
    }
    @Test
    public void TestIteratorWithMixedMultipleFirstPriorityAndSecondPriority() {
        testProject.add(importantAndUrgentTask);
        testProject.add(importantAndUrgentProject);
        testProject.add(importantButNotUrgentTask);
        testProject.add(importantButNotUrgentProject);
        int counter = 0;
        for (Todo t: testProject) {
            counter++;
            if (counter <= 2) {
                assertEquals(importantAndUrgentPriority, t.getPriority());
                System.out.println(t.getPriority());
            } else {
                assertEquals(importantButNotUrgentPriority, t.getPriority());
                System.out.println(t.getPriority());
            }
        }
    }
    @Test
    public void TestIteratorWithMixedMultipleSecondPriorityAndFirstPriority() {
        testProject.add(importantButNotUrgentTask);
        testProject.add(importantButNotUrgentProject);
        testProject.add(importantAndUrgentTask);
        testProject.add(importantAndUrgentProject);
        int counter = 0;
        for (Todo t: testProject) {
            counter++;
            if (counter <= 2) {
                assertEquals(importantAndUrgentPriority, t.getPriority());
                System.out.println(t.getPriority());
            } else {
                assertEquals(importantButNotUrgentPriority, t.getPriority());
                System.out.println(t.getPriority());
            }
        }
    }

    @Test
    public void TestIteratorWithMixedOneFirstPriorityAndThirdPriority() {
        testProject.add(importantAndUrgentTask);
        testProject.add(urgentButNotImportantTask);
        int counter = 0;
        for (Todo t: testProject) {
            counter++;
            if (counter == 1) {
                assertEquals(importantAndUrgentPriority, t.getPriority());
            } else {
                assertEquals(urgentButNotImportantPriority, t.getPriority());
            }
        }
    }
    @Test
    public void TestIteratorWithMixedOneThirdPriorityAndFirstPriority() {
        testProject.add(urgentButNotImportantTask);
        testProject.add(importantAndUrgentTask);
        int counter = 0;
        for (Todo t: testProject) {
            counter++;
            if (counter == 1) {
                assertEquals(importantAndUrgentPriority, t.getPriority());
            } else {
                assertEquals(urgentButNotImportantPriority, t.getPriority());
            }
        }
    }
    @Test
    public void TestIteratorWithMixedMultipleFirstPriorityAndThirdPriority() {
        testProject.add(importantAndUrgentTask);
        testProject.add(importantAndUrgentProject);
        testProject.add(urgentButNotImportantTask);
        testProject.add(urgentButNotImportantProject);
        int counter = 0;
        for (Todo t: testProject) {
            counter++;
            if (counter <= 2) {
                assertEquals(importantAndUrgentPriority, t.getPriority());
                System.out.println(t.getPriority());
            } else {
                assertEquals(urgentButNotImportantPriority, t.getPriority());
                System.out.println(t.getPriority());
            }
        }
    }
    @Test
    public void TestIteratorWithMixedMultipleThirdPriorityAndFirstPriority() {
        testProject.add(urgentButNotImportantTask);
        testProject.add(urgentButNotImportantProject);
        testProject.add(importantAndUrgentTask);
        testProject.add(importantAndUrgentProject);
        int counter = 0;
        for (Todo t: testProject) {
            counter++;
            if (counter <= 2) {
                assertEquals(importantAndUrgentPriority, t.getPriority());
                System.out.println(t.getPriority());
            } else {
                assertEquals(urgentButNotImportantPriority, t.getPriority());
                System.out.println(t.getPriority());
            }
        }
    }

    @Test
    public void TestIteratorWithMixedOneFirstPriorityAndFourthPriority() {
        testProject.add(importantAndUrgentTask);
        testProject.add(neitherImportantNorUrgentTask);
        int counter = 0;
        for (Todo t: testProject) {
            counter++;
            if (counter == 1) {
                assertEquals(importantAndUrgentPriority, t.getPriority());
            } else {
                assertEquals(neitherImportantNorUrgentPriority, t.getPriority());
            }
        }
    }
    @Test
    public void TestIteratorWithMixedOneFourthPriorityAndFirstPriority() {
        testProject.add(neitherImportantNorUrgentTask);
        testProject.add(importantAndUrgentTask);
        int counter = 0;
        for (Todo t: testProject) {
            counter++;
            if (counter == 1) {
                assertEquals(importantAndUrgentPriority, t.getPriority());
            } else {
                assertEquals(neitherImportantNorUrgentPriority, t.getPriority());
            }
        }
    }
    @Test
    public void TestIteratorWithMixedMultipleFirstPriorityAndFourthPriority() {
        testProject.add(importantAndUrgentTask);
        testProject.add(importantAndUrgentProject);
        testProject.add(neitherImportantNorUrgentTask);
        testProject.add(neitherImportantNorUrgentProject);
        int counter = 0;
        for (Todo t: testProject) {
            counter++;
            if (counter <= 2) {
                assertEquals(importantAndUrgentPriority, t.getPriority());
                System.out.println(t.getPriority());
            } else {
                assertEquals(neitherImportantNorUrgentPriority, t.getPriority());
                System.out.println(t.getPriority());
            }
        }
    }
    @Test
    public void TestIteratorWithMixedMultipleFourthPriorityAndFirstPriority() {
        testProject.add(neitherImportantNorUrgentTask);
        testProject.add(neitherImportantNorUrgentProject);
        testProject.add(importantAndUrgentTask);
        testProject.add(importantAndUrgentProject);
        int counter = 0;
        for (Todo t: testProject) {
            counter++;
            if (counter <= 2) {
                assertEquals(importantAndUrgentPriority, t.getPriority());
                System.out.println(t.getPriority());
            } else {
                assertEquals(neitherImportantNorUrgentPriority, t.getPriority());
                System.out.println(t.getPriority());
            }
        }
    }

    @Test
    public void TestIteratorWithMixedMultipleOfPriorityInEachQuadrant() {
        testProject.add(neitherImportantNorUrgentTask);
        testProject.add(neitherImportantNorUrgentProject);
        testProject.add(urgentButNotImportantTask);
        testProject.add(urgentButNotImportantProject);
        testProject.add(importantButNotUrgentTask);
        testProject.add(importantButNotUrgentProject);
        testProject.add(importantAndUrgentTask);
        testProject.add(importantAndUrgentProject);
        int counter = 0;
        for (Todo t: testProject) {
            counter++;
            if (counter <= 2) {
                assertEquals(importantAndUrgentPriority, t.getPriority());
                System.out.println(t.getPriority());
            } else if (counter <= 4){
                assertEquals(importantButNotUrgentPriority, t.getPriority());
                System.out.println(t.getPriority());
            } else if (counter <= 6) {
                assertEquals(urgentButNotImportantPriority, t.getPriority());
                System.out.println(t.getPriority());
            } else {
                assertEquals(neitherImportantNorUrgentPriority, t.getPriority());
                System.out.println(t.getPriority());
            }
        }
    }

    @Test
    public void TestIteratorWithOneImportantAndUrgentTodoAndOneSubProject() {
        Project nullProject = new Project("NullProject");
        testProject.add(nullProject);
        nullProject.add(importantAndUrgentProject);
        Iterator iterator = testProject.iterator();
        assertTrue(iterator.hasNext());
        assertEquals(nullProject,iterator.next());
        assertFalse(iterator.hasNext());
        try {
            iterator.next();
        } catch (NoSuchElementException e) {
            // expected
        }
        for (Todo t: testProject) {
            assertEquals(neitherImportantNorUrgentPriority, t.getPriority());
        }
        for (Todo t: testProject) {
            System.out.println(t.getDescription());
        }
    }
    @Test
    public void TestIteratorWithOneImportantAndUrgentTodoWithMultipleSubProjects() {

        testProject.add(importantAndUrgentProject);
        importantAndUrgentProject.add(importantAndUrgentProject);
        importantAndUrgentProject.add(importantButNotUrgentProject);
        importantAndUrgentProject.add(urgentButNotImportantProject);
        importantAndUrgentProject.add(neitherImportantNorUrgentProject);

        Iterator iterator = testProject.iterator();
        assertTrue(iterator.hasNext());
        assertEquals(importantAndUrgentProject,iterator.next());
        assertFalse(iterator.hasNext());
        for (Todo t: testProject) {
            assertEquals(importantAndUrgentPriority, t.getPriority());
        }
        for (Todo t: testProject) {
            System.out.println(t.getDescription());
        }
    }
    @Test
    public void TestIteratorWithOneImportantAndUrgentTodoWithMultipleSubProjectsAndTasks() {
        testProject.add(importantAndUrgentTask);
        testProject.add(importantAndUrgentProject);
        testProject.add(importantButNotUrgentTask);
        testProject.add(urgentButNotImportantProject);

        urgentButNotImportantProject.add(importantButNotUrgentProject);
        urgentButNotImportantProject.add(importantButNotUrgentTask);
        urgentButNotImportantProject.add(importantAndUrgentProject);

        testProject.add(importantButNotUrgentProject);

        importantAndUrgentProject.add(importantButNotUrgentProject);
        importantAndUrgentProject.add(urgentButNotImportantTask);
        importantAndUrgentProject.add(importantButNotUrgentTask);
        importantAndUrgentProject.add(neitherImportantNorUrgentProject);

        Iterator iterator = testProject.iterator();
        assertTrue(iterator.hasNext());

        assertEquals(importantAndUrgentTask,iterator.next());
        assertTrue(iterator.hasNext());

        assertEquals(importantAndUrgentProject,iterator.next());
        assertTrue(iterator.hasNext());

        assertEquals(importantButNotUrgentTask,iterator.next());
        assertTrue(iterator.hasNext());

        assertEquals(importantButNotUrgentProject,iterator.next());
        assertTrue(iterator.hasNext());

        assertEquals(urgentButNotImportantProject,iterator.next());
        assertFalse(iterator.hasNext());

        try {
            iterator.next();
            fail("");
        } catch (NoSuchElementException e) {
            // expected
        }
        try {
            iterator.next();
        } catch (NoSuchElementException e) {
            // expected
        }

        int counter = 0;
        for (Todo t: testProject) {
            counter++;
            if (counter == 1) {
                assertEquals(importantAndUrgentPriority, t.getPriority());
            } else if (counter == 2) {
                assertEquals(importantAndUrgentPriority, t.getPriority());
            } else if (counter <= 4) {
                assertEquals(importantButNotUrgentPriority, t.getPriority());
            } else if (counter == 5) {
                assertEquals(urgentButNotImportantPriority, t.getPriority());
            }
        }
    }
    @Test
    public void TestIteratorWithMixedMultipleOfPriorityInEachQuadrantAndSubProjects() {
        testProject.add(neitherImportantNorUrgentTask);
        testProject.add(neitherImportantNorUrgentProject);
        neitherImportantNorUrgentProject.add(importantButNotUrgentProject);
        testProject.add(urgentButNotImportantTask);
        testProject.add(urgentButNotImportantProject);
        testProject.add(importantButNotUrgentTask);
        testProject.add(importantButNotUrgentProject);
        importantButNotUrgentProject.add(importantAndUrgentTask);
        testProject.add(importantAndUrgentTask);
        testProject.add(importantAndUrgentProject);
        int counter = 0;
        for (Todo t: testProject) {
            counter++;
            if (counter <= 2) {
                assertEquals(importantAndUrgentPriority, t.getPriority());
                System.out.println(t.getPriority());
            } else if (counter <= 4){
                assertEquals(importantButNotUrgentPriority, t.getPriority());
                System.out.println(t.getPriority());
            } else if (counter <= 6) {
                assertEquals(urgentButNotImportantPriority, t.getPriority());
                System.out.println(t.getPriority());
            } else {
                assertEquals(neitherImportantNorUrgentPriority, t.getPriority());
                System.out.println(t.getPriority());
            }
        }
    }

    @Test
    public void TestIteratorNoSuchElementException() {
        try {
            for (Todo t: testProject) {
                fail("No such element though");
            }
        } catch (NoSuchElementException e) {
             // expected
        }
    }
    @Test
    public void TestGetTasksUnsupportedException() {
        try {
            testProject.getTasks();
            fail("given operation is not supported");
        } catch (UnsupportedOperationException e) {
           //expected
        }
    }
}
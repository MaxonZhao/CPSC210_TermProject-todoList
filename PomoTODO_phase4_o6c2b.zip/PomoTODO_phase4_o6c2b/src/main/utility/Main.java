package utility;

import model.Task;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
//        JsonFileIO ioReader = new JsonFileIO();
//        List<Task> tasks = new ArrayList<>();
//        try {
//            tasks = ioReader.read();
//        } catch (IOException e) {
//            System.out.println("Fuck Tim");
//        }
//        for (Task task: tasks) {
//            System.out.println(task.toString());
//        }
//        System.out.println(tasks.size());
//        try {
//              Task task = new Task("UBC is the best");
//              tasks.remove(task);
//             ioReader.write(tasks);
//        } catch (IOException e) {
//            System.out.println("haha");
//        }
//        try {
//            tasks = ioReader.read();
//        } catch (IOException e) {
//            System.out.println("Fuck Tim");
//        }
//        for (Task task: tasks) {
//            System.out.println(task.toString());
//        }
    }
}

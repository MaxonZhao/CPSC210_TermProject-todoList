package utility;

import model.Task;
import org.json.JSONArray;
import org.json.JSONObject;
import parsers.TaskParser;
import persistence.Jsonifier;

import java.io.*;
import java.util.Formatter;
import java.util.List;
import java.util.Scanner;

// File input/output operations
public class JsonFileIO {
    public static final File jsonDataFile = new File("./resources/json/tasks.json");
    public static final File testJsonDataFile = new File("./resources/json/testTasks.json");

    // EFFECTS: attempts to read jsonDataFile and parse it
    //           returns a list of tasks from the content of jsonDataFile
    public static List<Task> read() throws IOException {
        Scanner textScanner;
        textScanner = new Scanner(jsonDataFile);
        String taskStringInput = "";
        while (textScanner.hasNext()) {
            taskStringInput += textScanner.nextLine();
        }
        //System.out.println(taskStringInput);
        TaskParser taskParser = new TaskParser();
        List<Task> tasks = taskParser.parse(taskStringInput);
        textScanner.close();
        return tasks;
    }

    // EFFECTS: saves the tasks to jsonDataFile
    public static void write(List<Task> tasks) throws IOException {
        // stub
        BufferedWriter textWriter = new BufferedWriter(new FileWriter(jsonDataFile));;
        String taskInputString = "";
        Jsonifier tasksInJsonFormat = new Jsonifier();
        taskInputString = tasksInJsonFormat.taskListToJson(tasks).toString(2);
       // System.out.println(taskInputString);
        textWriter.write(taskInputString);
        textWriter.close();
    }
}

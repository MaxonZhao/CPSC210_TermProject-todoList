package model;

import model.exceptions.EmptyStringException;
import model.exceptions.NullArgumentException;

import java.security.Key;
import java.util.*;

// Represents a Project, a collection of zero or more Tasks
// Class Invariant: no duplicated task; order of tasks is preserved
public class Project extends Todo implements Iterable<Todo>, Observer {
    private List<Todo> tasks;
    private Map<Todo,Integer> etcHoursOfTodos;

    // MODIFIES: this
    // EFFECTS: constructs a project with the given description
    //     the constructed project shall have no tasks.
    //  throws EmptyStringException if description is null or empty
    public Project(String description) {
        super(description);
        tasks = new ArrayList<>();
        etcHoursOfTodos = new HashMap<>();
        this.priority = new Priority(4);
    }

    // MODIFIES: this
    // EFFECTS: task is added to this project (if it was not already part of it)
    //   throws NullArgumentException when task is null
    public void add(Todo task) {

        if (!contains(task) && !this.equals(task)) {
            tasks.add(task);
            task.addObserver(this);
            update(task, null);
//            setChanged();
//            notifyObservers(null);
        }
    }

    // MODIFIES: this
    // EFFECTS: removes task from this project
    //   throws NullArgumentException when task is null
    public void remove(Todo task) {
        if (contains(task)) {
            tasks.remove(task);
            update(task, this);
            task.deleteObserver(this);
        }
    }

    // EFFECTS: returns the description of this project
    public String getDescription() {
        return description;
    }

    @Override
    public int getEstimatedTimeToComplete() {
//        int estimatedTime = 0;
//        for (Todo todo : tasks) {
//            estimatedTime += todo.getEstimatedTimeToComplete();
//        }
//        return estimatedTime;
        //System.out.println(etcHours);
        return etcHours;
    }

    // EFFECTS: returns an unmodifiable list of tasks in this project.
    public List<Task> getTasks() {
        throw new UnsupportedOperationException();
    }

    // EFFECTS: returns an integer between 0 and 100 which represents
    //     the percentage of completion (rounded down to the nearest integer).
    //     the value returned is the average of the percentage of completion of
    //     all the tasks and sub-projects in this project.
    public int getProgress() {
        int progress = 0;
        int taskCounter = 0;
        List<Integer> projectProgress = new ArrayList<>();
        for (Todo todo : tasks) {
            if (todo instanceof Project) {
                projectProgress.add(todo.getProgress());
            } else {
                progress += todo.getProgress();
                taskCounter++;
            }
        }
        if (taskCounter == 0) {
            return this.progress;
        } else {
            return returnProjectProgress(projectProgress, progress, taskCounter);
        }
    }

    private int returnProjectProgress(List<Integer> projectProgress, int progress, int taskCounter) {
        if (projectProgress.isEmpty()) {
            return (progress / taskCounter);
        } else {
            int total = 0;
            for (Integer i : projectProgress) {
                total += i;
            }
            return (progress / taskCounter + total) / (projectProgress.size() + 1);
        }
    }

    // EFFECTS: returns the number of tasks (and sub-projects) in this project
    public int getNumberOfTasks() {
        return tasks.size();
    }

    // EFFECTS: returns true if every task (and sub-project) in this project is completed, and false otherwise
    //     If this project has no tasks (or sub-projects), return false.
    public boolean isCompleted() {
        return getNumberOfTasks() != 0 && getProgress() == 100;
    }

    // EFFECTS: returns true if this project contains the task
    //   throws NullArgumentException when task is null
    public boolean contains(Todo task) {
        if (task == null) {
            throw new NullArgumentException("Illegal argument: task is null");
        }
        return tasks.contains(task);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Project)) {
            return false;
        }
        Project project = (Project) o;
        return Objects.equals(description, project.description);
    }

    @Override
    public int hashCode() {
        return Objects.hash(description);
    }

    @Override
    public Iterator<Todo> iterator() {
        return new ProjectIterator();
    }


    @Override
    public void update(Observable o, Object arg) {
        Todo todo = (Todo) o;
        int totalHours = 0;
        if (arg != null) {
            etcHoursOfTodos.put(todo, 0);
        } else {
            etcHoursOfTodos.put(todo, todo.getEstimatedTimeToComplete());
        }
        for (Map.Entry<Todo,Integer> entry: etcHoursOfTodos.entrySet()) {
            totalHours += entry.getValue();
        }
        etcHours = totalHours;
        if (this.countObservers() > 0) {
            setChanged();
            this.notifyObservers();
        }
    }

    private class ProjectIterator implements Iterator<Todo> {
        private int importantAndUrgentTodoIndex;
        private int importantButNotUrgentTodoIndex;
        private int urgentButNotImportantIndex;
        private int neitherImportantNorUrgentIndex;

        public ProjectIterator() {
            importantAndUrgentTodoIndex = 0;
            importantButNotUrgentTodoIndex = 0;
            urgentButNotImportantIndex = 0;
            neitherImportantNorUrgentIndex = 0;
        }

        @Override
        public boolean hasNext() {
            boolean hasNext;
            if (hasNextImportantAndUrgentTodo()) {
                hasNext = true;
            } else if (hasNextImportantButNotUrgentTodo()) {
                hasNext = true;
            } else if (hasNextUrgentButNotImportantTodo()) {
                hasNext = true;
            } else if (hasNextNeitherImportantNorUrgentTodo()) {
                hasNext = true;
            } else {
                hasNext = false;
            }
            return hasNext;
        }

        private boolean hasNextImportantAndUrgentTodo() {
            for (int i = importantAndUrgentTodoIndex; i < tasks.size(); ++i) {
                if (tasks.get(i).getPriority().isImportant() && tasks.get(i).getPriority().isUrgent()) {
                    return true;
                }
            }
            return false;
        }

        private boolean hasNextImportantButNotUrgentTodo() {

            for (int i = importantButNotUrgentTodoIndex; i < tasks.size(); ++i) {
                if (tasks.get(i).getPriority().isImportant() && !tasks.get(i).getPriority().isUrgent()) {
                    return true;
                }
            }
            return false;
        }

        private boolean hasNextUrgentButNotImportantTodo() {

            for (int i = urgentButNotImportantIndex; i < tasks.size(); ++i) {
                if (!tasks.get(i).getPriority().isImportant() && tasks.get(i).getPriority().isUrgent()) {
                    return true;
                }
            }
            return false;
        }

        private boolean hasNextNeitherImportantNorUrgentTodo() {

            for (int i = neitherImportantNorUrgentIndex; i < tasks.size(); ++i) {
                if (!tasks.get(i).getPriority().isImportant() && !tasks.get(i).getPriority().isUrgent()) {
                    return true;
                }
            }
            return false;
        }

        @Override
        public Todo next() {
            Todo nextTodo;
            if (!hasNext()) {
                throw new NoSuchElementException();
            } else if (hasNextImportantAndUrgentTodo()) {
                nextTodo = getNextImportantAndUrgentTodo();
            } else if (hasNextImportantButNotUrgentTodo()) {
                nextTodo = getNextImportantButNotUrgentTodo();
            } else if (hasNextUrgentButNotImportantTodo()) {
                nextTodo = getNextUrgentButNotImportantTodo();
            } else {
                nextTodo = getNextNeitherImportantNorUrgentTodo();
            }
           // System.out.println(nextTodo.getDescription());
            return nextTodo;
        }

        private Todo getNextImportantAndUrgentTodo() {
            for (int i = importantAndUrgentTodoIndex; i < tasks.size(); ++i) {
                if (tasks.get(i).getPriority().isImportant() && tasks.get(i).getPriority().isUrgent()) {
                    importantAndUrgentTodoIndex = i + 1;
                    break;
                }
            }
            return tasks.get(importantAndUrgentTodoIndex - 1);
        }

        private Todo getNextImportantButNotUrgentTodo() {

            for (int i = importantButNotUrgentTodoIndex; i < tasks.size(); ++i) {
                if (tasks.get(i).getPriority().isImportant() && !tasks.get(i).getPriority().isUrgent()) {
                    importantButNotUrgentTodoIndex = i + 1;
                    break;
                }
            }
            return tasks.get(importantButNotUrgentTodoIndex - 1);
        }

        private Todo getNextUrgentButNotImportantTodo() {

            for (int i = urgentButNotImportantIndex; i < tasks.size(); ++i) {
                if (!tasks.get(i).getPriority().isImportant() && tasks.get(i).getPriority().isUrgent()) {
                    urgentButNotImportantIndex = i + 1;
                    break;
                }
            }
            return tasks.get(urgentButNotImportantIndex - 1);
        }

        private Todo getNextNeitherImportantNorUrgentTodo() {

            for (int i = neitherImportantNorUrgentIndex; i < tasks.size(); ++i) {
                if (!tasks.get(i).getPriority().isImportant() && !tasks.get(i).getPriority().isUrgent()) {
                    neitherImportantNorUrgentIndex = i + 1;
                    break;
                }
            }
            return tasks.get(neitherImportantNorUrgentIndex - 1);
        }
    }

}
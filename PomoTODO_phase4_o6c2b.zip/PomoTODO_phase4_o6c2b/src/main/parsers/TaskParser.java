package parsers;

import model.*;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import persistence.Jsonifier;

import java.util.*;

// Represents Task parser
public class TaskParser {
    private List<Task> tasks = new ArrayList<>();
    private JSONArray tasksArray = null;
    private String taskDescription;
    private Set<Tag> tags = new LinkedHashSet<>();
    private DueDate taskDueDate = null;
    private Status taskStatus = Status.TODO;
    private Priority taskPriority = new Priority();
    private Task task;
    private int year = 0;
    private int month = 0;
    private int date = 0;
    private int hour = 0;
    private int minute = 0;
    private List<String> taskStrings = new ArrayList<>();
    private boolean flag = true;

    // EFFECTS: iterates over every JSONObject in the JSONArray represented by the input
    // string and parses it as a task; each parsed task is added to the list of tasks.
    // Any task that cannot be parsed due to malformed JSON data is not added to the
    // list of tasks.
    // Note: input is a string representation of a JSONArray
    public List<Task> parse(String input) {
        taskStringSeparator(input);
        for (String string : taskStrings) {
            try {
                tasksArray = new JSONArray(string);
                for (Object object : tasksArray) {
                    JSONObject taskJson = (JSONObject) object;
                    parseEachField(taskJson);
                    setupTask();
                    if (flag) {
                        tasks.add(task);
                    }
                    flag = true;
                    tags = new LinkedHashSet<>();
                    //System.out.println(task.toString());
                }
            } catch (JSONException e) {
                //
            }
        }
        return tasks;
    }

    private void setupTask() {
        task = new Task(taskDescription);
        for (Tag tag : tags) {
            task.addTag(tag);
        }
        task.setDueDate(taskDueDate);
        task.setStatus(taskStatus);
        task.setPriority(taskPriority);
    }

    private void taskStringSeparator(String input) {
        while (input.indexOf("},\n{") != -1) {
            int index = input.indexOf("},\n{");
            String string = input.substring(0, index + 1);
            string += "]";
            taskStrings.add(string);
            input = "[" + input.substring(index + 2);
        }
        taskStrings.add(input);
    }

    private void parseEachField(JSONObject taskJson) {
        descriptionParser(taskJson);
        dueDateParser(taskJson);
        priorityParser(taskJson);
        statusParser(taskJson);
        tagsParser(taskJson);
    }

    private void descriptionParser(JSONObject obj) {
        taskDescription = obj.optString("description");
        if (taskDescription.isEmpty()) {
            taskDescription = "false";
            flag = false;
        }
    }

    private void dueDateParser(JSONObject obj) {
        if (!obj.toString().contains("due-date")) {
            flag = false;
        }
        obj = obj.optJSONObject("due-date");
        if (obj != null) {
            setupDueDate(obj);
            Calendar dueCal = Calendar.getInstance();
            dueCal.set(Calendar.YEAR, year);
            dueCal.set(Calendar.MONTH, month);
            dueCal.set(Calendar.DATE, date);
            dueCal.set(Calendar.HOUR_OF_DAY, hour);
            dueCal.set(Calendar.MINUTE, minute);
            taskDueDate = new DueDate(dueCal.getTime());
        } else {
            taskDueDate = null;
            //flag = false;
        }
    }

    private void setupDueDate(JSONObject obj) {
        year = obj.getInt("year");
        month = obj.getInt("month");
        date = obj.getInt("day");
        hour = obj.getInt("hour");
        minute = obj.getInt("minute");
    }

    private void statusParser(JSONObject obj) {
        /*
        String statusString = obj.optString("status", "TOD");
        if (statusString.equals("IN_PROGRESS")) {
            taskStatus = Status.IN_PROGRESS;
        } else {
            taskStatus = Status.TOD;
        }
        */

        Status status = obj.optEnum(Status.class, "status");
        if (status == null) {
            flag = false;
        } else {
            taskStatus = status;
        }
    }

    private void priorityParser(JSONObject obj) {
        obj = obj.optJSONObject("priority");
        if (obj == null) {
            flag = false;
        } else {
            boolean isImportant = obj.getBoolean("important");
            boolean isUrgent = obj.getBoolean("urgent");
            taskPriority = new Priority();
            taskPriority.setImportant(isImportant);
            taskPriority.setUrgent(isUrgent);
        }
    }

    public void tagsParser(JSONObject taskJson) {
        JSONArray tagsJson = taskJson.optJSONArray("tags");
        if (tagsJson == null) {
            flag = false;
        } else {
            for (Object obj : tagsJson) {
                JSONObject tagJson = (JSONObject) obj;
                String tagName = tagJson.getString("name");
                Tag tag = new Tag(tagName);
                tags.add(tag);
            }
        }
    }
}

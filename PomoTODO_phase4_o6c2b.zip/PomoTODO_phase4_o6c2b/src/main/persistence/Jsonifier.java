package persistence;


import model.DueDate;
import model.Priority;
import model.Tag;
import model.Task;
import org.json.JSONArray;
import org.json.JSONObject;
import utility.JsonFileIO;

import java.time.Year;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

// Converts model elements to JSON objects
public class Jsonifier {

    // EFFECTS: returns JSON representation of tag
    public static JSONObject tagToJson(Tag tag) {
        JSONObject tagJson = new JSONObject();
        tagJson.put("name", tag.getName());
        return tagJson;
    }

    // EFFECTS: returns JSON representation of priority
    public static JSONObject priorityToJson(Priority priority) {
        JSONObject priorityJson = new JSONObject();
        priorityJson.put("important",priority.isImportant());
        priorityJson.put("urgent",priority.isUrgent());
        return priorityJson;
    }

    // EFFECTS: returns JSON respresentation of dueDate
    public static JSONObject dueDateToJson(DueDate dueDate) {
        Calendar cal = Calendar.getInstance();
        JSONObject dueDateJson;
        if (dueDate != null) {
            dueDateJson = new JSONObject();
            cal.setTime(dueDate.getDate());
            dueDateJson.put("year",cal.get(Calendar.YEAR));
            dueDateJson.put("month",cal.get(Calendar.MONTH));
            dueDateJson.put("day",cal.get(Calendar.DATE));
            dueDateJson.put("hour",cal.get(Calendar.HOUR_OF_DAY));
            dueDateJson.put("minute",cal.get(Calendar.MINUTE));
        } else {
            return new JSONObject();
        }
        return dueDateJson;
    }

    // EFFECTS: returns JSON representation of task
    public static JSONObject taskToJson(Task task) {
        JSONObject taskJson = new JSONObject();
        taskJson.put("description",task.getDescription());
        JSONArray tagsJsonArray = new JSONArray();
        for (Tag tag: task.getTags()) {
            tagsJsonArray.put(tagToJson(tag));
        }
        taskJson.put("tags", tagsJsonArray);
        if (task.getDueDate() == null) {
            taskJson.put("due-date", JSONObject.wrap(null));
        } else {
            taskJson.put("due-date", dueDateToJson(task.getDueDate()));
        }
        taskJson.put("priority",priorityToJson(task.getPriority()));
        taskJson.put("status",task.getStatus());
        return taskJson;
    }

    // EFFECTS: returns JSON array representing list of tasks
    public static JSONArray taskListToJson(List<Task> tasks) {
        JSONArray tasksArray = new JSONArray();
        for (Task task: tasks) {
            tasksArray.put(taskToJson(task));
        }
        return tasksArray;   // stub
    }
}
